# Glass Message Board

A frosted-glass message board for Home Assistant. Leave notes for the household on a wall tablet: type, dictate, or draw them by hand; address them to one person or everyone; react with emoji; pin what matters and let the rest expire. When nobody's touching the tablet it drifts into an ambient clock that spotlights the latest notes.

One install gives you both pieces:

- **Integration** (`glass_messages`): stores notes, expires them, exposes services, sensors and an event, and pings phones.
- **Dashboard card** (`custom:glass-message-board`): served and loaded by the integration automatically. No resource to add by hand.

## Features

| | |
|---|---|
| Per-person notes | From/To chips for every `person` entity, with their pictures. "For you" notes glow. |
| Write, dictate, draw | Big touch textarea, quick emoji, voice dictation (browser speech recognition), and a handwriting pad with six inks, three pen sizes and undo. |
| Pin & expiry | 1 hour, Tonight, 1 day, 1 week, or keep. Pinned notes never expire and sort first. Expired notes are purged every minute. |
| Reactions & replies | Tap a note to react (❤️ 😂 👍 🎉 😮 🙏), reply to the sender, pin or delete it. |
| Ambient mode | After a configurable idle time: huge clock, date, and a rotating spotlight of notes, preferring ones for the person logged in on the tablet. Tap to wake. |
| Automations | `glass_messages.post` and friends, a `glass_messages_new` event, and sensors per person. |
| Notifications | Map each person to one or more `notify.*` services; they get a push when a note is left for them. |

## Install

**HACS (custom repository)**
1. HACS → ⋮ → *Custom repositories* → add this repo's URL, category **Integration**.
2. Install **Glass Message Board**, then restart Home Assistant.

**Manual**
Copy `custom_components/glass_messages` into your `config/custom_components/` folder and restart.

Then: **Settings → Devices & services → Add integration → Glass Message Board.**

Requires Home Assistant 2024.11 or newer.

## Add the card

On a wall tablet, use a **Panel** view (or a full-width Sections view) so the board fills the screen:

```yaml
type: custom:glass-message-board
title: Family notes
ambient_after: 90        # seconds of idle before ambient mode; 0 = off
height: 100vh            # any CSS height; default fills the viewport under the header
column_width: 300        # approximate note width in px
show_clock: true
background_image: /local/wallpaper.jpg   # optional, shows through the glass
```

The card also has a visual editor.

Tips for tablets: run the dashboard in kiosk mode (e.g. the Fully Kiosk Browser app or HA's own kiosk options), and serve Home Assistant over **HTTPS**, which browsers require for microphone dictation.

## Notifications

**Settings → Devices & services → Glass Message Board → Configure.** For each person, pick the notify service(s) for their phone, e.g. `notify.mobile_app_pixel_8`.

- Note to a person → their services are notified.
- Note to Everyone → every mapped person except the sender, plus any "extra" services.
- *Notification tap path* (e.g. `/lovelace/notes`) opens the board when the notification is tapped.
- *Default note lifetime* sets which expiry chip is preselected (0 = keep).

## Services

```yaml
# Leave a note from an automation
action: glass_messages.post
data:
  message: "Washer is done 🧺"
  to: everyone            # or person.maya
  sender_name: Laundry    # shown with a 🏠 avatar when not from a person
  expires_in: 120         # minutes  (or expires_at: "2026-11-01 08:00")
  tint: mint              # clear | rose | amber | mint | sky | violet
  pinned: false
  notify: true
response_variable: note   # note.id, if you want to delete it later
```

| Action | Fields |
|---|---|
| `glass_messages.post` | `message`, `to`, `from`, `sender_name`, `expires_in`, `expires_at`, `pinned`, `tint`, `notify` |
| `glass_messages.delete` | `id` |
| `glass_messages.pin` | `id`, `pinned` |
| `glass_messages.react` | `id`, `emoji`, `from` |
| `glass_messages.clear` | `include_pinned` |

### Example: wake the tablet screen when a note arrives

```yaml
triggers:
  - trigger: event
    event_type: glass_messages_new
actions:
  - action: light.turn_on    # or your kiosk app's screen-on switch
    target:
      entity_id: light.hallway_tablet_screen
```

### Example: replace yesterday's note each morning

```yaml
triggers:
  - trigger: time
    at: "07:00:00"
actions:
  - action: glass_messages.post
    data:
      message: "Bins go out tonight 🗑️"
      sender_name: Home
      expires_in: 960
      tint: amber
```

## Entities & events

- `sensor.glass_message_board_messages`: number of notes on the board. Attributes: `pinned`, `latest_text`, `latest_from`, `latest_at`.
- `sensor.glass_message_board_messages_for_<person>`: notes addressed to that person or to everyone (excluding their own). Extra attribute `direct`.
- Event `glass_messages_new`: `id`, `text`, `has_drawing`, `sender`, `sender_name`, `recipient`, `pinned`.

## Who can delete

Admins, the sender, and the recipient. Anyone can react or pin.

## Data & limits

Notes live in `.storage/glass_messages.messages`. Up to 200 notes are kept (oldest unpinned go first); text up to 2,000 characters; drawings are stored as compact vector strokes, not images.

## Websocket API (for other frontends)

`glass_messages/subscribe` (snapshot, then `added` / `updated` / `removed` events), `glass_messages/post`, `glass_messages/delete`, `glass_messages/pin`, `glass_messages/react`.

## License

MIT
